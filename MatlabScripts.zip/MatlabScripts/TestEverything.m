% Test Everything

DesignMainStarter
CompareTwoModels

RunForwardTool
CreateWalkingModelAndEnvironment

AddClutchedPathSpring
AddCoordinateActuator
AddCoordinateActuatorPrescribedController
run('../Reference/AddCustomFeetComplete')
run('../Reference/AddExpressionPointToPointForceMagnetsComplete')
AddMillardMuscle
AddPathActuator
AddPathSpring
AddSpringGeneralizedForce


