% ----------------------------------------------------------------------- 
% The OpenSim API is a toolkit for musculoskeletal modeling and           
% simulation. See http://opensim.stanford.edu and the NOTICE file         
% for more information. OpenSim is developed at Stanford University       
% and supported by the US National Institutes of Health (U54 GM072970,    
% R24 HD065690) and by DARPA through the Warrior Web program.             
%                                                                         
% Copyright (c) 2005-2013 Stanford University and the Authors             
% Author(s): Chris Dembia                                           
%                                                                         
% Licensed under the Apache License, Version 2.0 (the "License");         
% you may not use this file except in compliance with the License.        
% You may obtain a copy of the License at                                 
% http://www.apache.org/licenses/LICENSE-2.0.                             
%                                                                         
% Unless required by applicable law or agreed to in writing, software     
% distributed under the License is distributed on an "AS IS" BASIS,       
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or         
% implied. See the License for the specific language governing            
% permissions and limitations under the License.                          
% -----------------------------------------------------------------------
% Import Java Library 
import org.opensim.modeling.*

% Open the model
walkerModel = Model('../Model/DW2013_WalkerModelTerrain.osim');

% Change the name
walkerModel.setName('DW2013_WalkerModelTerrainAddCoordinateActuatorPrescribedController');

%% CoordinateActuator

% Parameters
minControl = 0.0;
maxControl = 50.0;

% Right hip
rightHipAct = CoordinateActuator('RHip_rz');
rightHipAct.setName('right_hip_actuator');
rightHipAct.setMinControl(minControl);
rightHipAct.setMaxControl(maxControl);

% Left hip
leftHipAct = CoordinateActuator('LHip_rz');
leftHipAct.setName('left_hip_actuator');
leftHipAct.setMinControl(minControl);
leftHipAct.setMaxControl(maxControl);

% Add the actuators to the model.
walkerModel.addForce(rightHipAct);
walkerModel.addForce(leftHipAct);

%% Controlling the CoordinateActuators

% We just need one controller for both actuators.
controller = PrescribedController();
controller.setName('gait_controller');

% This controller will control all actuators in the model.
controller.setActuators(walkerModel.getActuators());

% Add the controller to the model.
walkerModel.addController(controller);

% We define functions that specify/prescribe the control.
rightFcn = PiecewiseConstantFunction();
rightFcn.setName('right_hip_prescribed_fcn');

leftFcn = PiecewiseConstantFunction();
leftFcn.setName('left_hip_prescribed_fcn');

% *** USER CODE GOES HERE *** to define these functions
% first input is time value, second input is control value (force/torque).
rightFcn.addPoint(0, 0);
rightFcn.addPoint(0.5, 3.0);

leftFcn.addPoint(0, 0);
leftFcn.addPoint(0.7, 3.0);
% *** ***

% Tell the controller about these functions, and associate them with the
% proper actuator we created above.
controller.prescribeControlForActuator('right_hip_actuator', rightFcn);
controller.prescribeControlForActuator('left_hip_actuator', leftFcn);

% Print a new model file.
walkerModel.print('../Model/DW2013_WalkerModelTerrainCoordinateActuatorPrescribedController.osim');
















